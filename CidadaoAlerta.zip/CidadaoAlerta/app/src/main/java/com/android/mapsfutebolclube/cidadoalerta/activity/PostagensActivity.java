package com.android.mapsfutebolclube.cidadoalerta.activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import com.android.mapsfutebolclube.cidadoalerta.R;
import com.android.mapsfutebolclube.cidadoalerta.helper.ConfiguracaoFirebase;
import com.google.firebase.auth.FirebaseAuth;

public class PostagensActivity extends AppCompatActivity {

    //será usado para mostrar o menu de acordo com o fato de o usuario estar logado ou nao
    private FirebaseAuth autenticacao = ConfiguracaoFirebase.getFirebaseAutenticacao();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_postagens);

    }

    //cria as opcoes do canto superior direito do app
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    //é chamado antes dos itens de menu serem exibidos -> permite alterar itens de acordo com o tipo de usuario, carregar itens, etc
    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {

        //mostra o menu de acordo com o fato de o usuario estar logado ou nao
        if( autenticacao.getCurrentUser() == null) { //usuario deslogado
            menu.setGroupVisible(R.id.group_deslogado, true);
        } else { // usuario logado
            menu.setGroupVisible(R.id.group_logado, true);
        }
        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.menu_cadastrar:
                startActivity(new Intent(getApplicationContext(), CadastroActivity.class));
                break;

            case R.id.menu_sair:
                autenticacao.signOut();
                invalidateOptionsMenu();
                break;
        }

        return super.onOptionsItemSelected(item);
    }
}
