package com.android.mapsfutebolclube.cidadoalerta.activity;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import com.android.mapsfutebolclube.cidadoalerta.R;
import com.android.mapsfutebolclube.cidadoalerta.helper.ConfiguracaoFirebase;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseAuthWeakPasswordException;

public class CadastroActivity extends AppCompatActivity {

    private Button botaoAcessar;
    private EditText campoEmail, campoSenha;
    private Switch tipoAcesso;

    //servirá para recuperar as referencias do Firebase, que estao na classe ConfiguracaoFirebase, no pacote helper
    private FirebaseAuth autenticacao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        //associa os elementos xml - java", ou seja, inicializa os componentes, formaliza os elementos de layout para que possam ser programados
        campoEmail = findViewById(R.id.editCadastroEmail);
        campoSenha = findViewById(R.id.editCadastroSenha);
        botaoAcessar = findViewById(R.id.buttonAcesso);
        tipoAcesso = findViewById(R.id.switchAcesso);

        //associa o conteudo do metodo da classe ConfiguracaoFirebase do pacote helper
        autenticacao = ConfiguracaoFirebase.getFirebaseAutenticacao();

        botaoAcessar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //recuperar o que o usuario digitou
                String email = campoEmail.getText().toString();
                String senha = campoSenha.getText().toString();

                //validar os campos
                if( !email.isEmpty()) {
                    if( !senha.isEmpty()){

                        //verifica se o switch esta acionado
                        if( tipoAcesso.isChecked()){ //cadastro - cria um usuario

                            autenticacao.createUserWithEmailAndPassword(email, senha).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    if( task.isSuccessful() ){

                                        Toast.makeText(CadastroActivity.this, "Cadastro realizado com sucesso", Toast.LENGTH_SHORT).show();

                                        //direciona o usuario para a tela principal do app


                                    }else {

                                        String erroExcecao = "";

                                        try {
                                            throw task.getException();
                                        } catch ( FirebaseAuthWeakPasswordException e) {
                                            erroExcecao = "Digite uma senha mais forte";
                                        } catch (FirebaseAuthInvalidCredentialsException e) {
                                            erroExcecao = "Insira um usuário válido";
                                        } catch (FirebaseAuthUserCollisionException e) {
                                            erroExcecao = "Essa conta ja existe";
                                        } catch (Exception e) {
                                            erroExcecao = "ao cadastrar usuario: " +e.getMessage();
                                            e.printStackTrace();
                                        }

                                        Toast.makeText(CadastroActivity.this, "Erro: " +erroExcecao, Toast.LENGTH_SHORT).show();

                                    }

                                }
                            });

                        } else { //login
                            autenticacao.signInWithEmailAndPassword(email, senha).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {

                                    if(task.isSuccessful()) {
                                        Toast.makeText(CadastroActivity.this, "Logado com sucesso", Toast.LENGTH_SHORT).show();
                                        startActivity(new Intent(getApplicationContext(), PostagensActivity.class));
                                    } else {
                                        Toast.makeText(CadastroActivity.this, "Erro ao fazer login: " +task.getException(), Toast.LENGTH_SHORT).show();
                                    }

                                }
                            });

                        }

                    } else {
                        Toast.makeText(CadastroActivity.this, "Preencha a senha!", Toast.LENGTH_SHORT).show();
                    }

                } else {
                    Toast.makeText(CadastroActivity.this, "Preencha o email", Toast.LENGTH_SHORT).show();
                }


            }
        });

    }


}
